<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
 */
use Illuminate\Http\Request;

$router->get('/', function () use ($router) {
    return $router->app->version();
});

$router->get("/contentFeed/{user_id}/",function(Request $req, $user_id){
    //DB commands will come here

    $content = app("db")->select("select * from content_topics");
    $data = array();
    foreach($content as $ct){
        $weight = 0;
        $contentAgeGroup = app("db")->select("select * from content_age_groups cg inner join user_age_groups ug on cg.age_group_id = ug.age_group_id where cg.item_id = ".$ct->item_id." and ug.user_id= ".$user_id);
        if(count($contentAgeGroup)>0)
             $weight+=1;
        $contentUserTopicMatch = app("db")->select("select * from content_topics ct inner join user_topics ut on ct.topic_id = ut.topic_id where ct.item_id = ".$ct->item_id." and ut.user_id= ".$user_id);
        if(count($contentUserTopicMatch)>0)
            $weight+=1;
        $cdate = app("db")->select("select * from content_date where item_id = ".$ct->item_id)[0];
     array_push($data,array("item_id"=>$ct->item_id,"weight"=>$weight,"cdate"=>strval($cdate->cdate)));

    }
    return response()->json($data);
});
$router->post("/logVisit/",function(Request $req){
    //DB commands will come hereA
    $user_id = $req->input("user_id");
    $item_id = $req->input("item_id");
    $item = app("db")->select("select * from content_topics where item_id = ".$item_id);
    if($item){
        $topic_id = app("db")->select("Select topic_id from content_topics where item_id=".$item_id)[0];
        $user_topic = app("db")->select("Select id from  user_topics where topic_id=".$topic_id->topic_id);
        if(empty($user_topic)){
            $user_topic = app("db")->table("user_topics")->insert(array(
                "user_id"=>$user_id,
                "topic_id"=>$topic_id->topic_id,
            ));
            return response(true);
        }
    }
    return response(false);
});


